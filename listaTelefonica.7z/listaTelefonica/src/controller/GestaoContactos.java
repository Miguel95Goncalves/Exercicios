package controller;

import java.util.ArrayList;
import model.Contacto;

public class GestaoContactos {
	
	public void addContacto(ArrayList<Contacto> lista,String nome,String email,String contacto,int idade){
		lista.add(new Contacto(nome,email,contacto,idade));
	}
	
	public void mostrarContactos(ArrayList<Contacto> lista){
		for(int i=0;i<lista.size();i++)
		{
			System.out.println("Nome: "+lista.get(i).getNome());
			System.out.println("Email: "+lista.get(i).getEmail());
			System.out.println("Contacto: "+lista.get(i).getContacto());
			System.out.println("idade: "+lista.get(i).getIdade());
		}
	}
	
	public void removerContacto(ArrayList<Contacto> lista,String contacto){
		for(int i=0;i<lista.size();i++)
		{
			if(contacto==lista.get(i).getContacto()) lista.remove(i);
		}
	}
	
}
