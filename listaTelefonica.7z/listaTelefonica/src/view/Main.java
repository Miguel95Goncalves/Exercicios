package view;

import model.Contacto;
import controller.GestaoContactos;
import java.util.Scanner;
import java.util.ArrayList;

public class Main {
	
	static Scanner read = (new Scanner(System.in));
	static ArrayList<Contacto> lista = new ArrayList<Contacto>();

	public static void main(String[] args) {
		int opc;
		
		do
		{
			System.out.println("1 - Inserir\n2 - Mostrar\n3 - Remover\nInsira a op��o: ");
			opc = read.nextInt();
			
			switch(opc)
			{
				case 1:
					Contacto c;
					String nome,email,contacto;
					int idade;
					
					read.nextLine();
					
					System.out.println("Insira o nome: ");
					nome = read.nextLine();
					
					System.out.println("Insira o email: ");
					email = read.nextLine();
					
					System.out.println("Insira o contacto: ");
					contacto = read.nextLine();
					
					System.out.println("Insira o idade: ");
					idade = read.nextInt();
					
					new GestaoContactos().addContacto(lista, nome,email,contacto,idade);
					break;
					
				case 2:
					new GestaoContactos().mostrarContactos(lista);
					break;
					
				case 3:
					System.out.println("Insira o contacto a remover: ");
					contacto = read.nextLine();
					new GestaoContactos().removerContacto(lista,contacto);
					break;
			}
			
		}while(opc!=0);
	}

}
