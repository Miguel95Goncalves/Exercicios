package model;

public class Contacto {
	private String nome;
	private String email;
	private String contacto;
	private int idade;
	
	public Contacto(String nome, String email, String contacto, int idade) {
		super();
		this.nome = nome;
		this.email = email;
		this.contacto = contacto;
		this.idade = idade;
	}
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getContacto() {
		return contacto;
	}
	public void setContacto(String contacto) {
		this.contacto = contacto;
	}
	public int getIdade() {
		return idade;
	}
	public void setIdade(int idade) {
		this.idade = idade;
	}
	
	
}
